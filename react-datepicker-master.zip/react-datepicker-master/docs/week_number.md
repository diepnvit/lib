# `week_number` (component)

| name                    | type     | default value | description |
| ----------------------- | -------- | ------------- | ----------- |
| `onClick`               | `func`   |               |             |
| `weekNumber` (required) | `number` |               |             |
