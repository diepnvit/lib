# `month_dropdown` (component)

| name                      | type                       | default value | description |
| ------------------------- | -------------------------- | ------------- | ----------- |
| `dateFormat` (required)   | `string`                   |               |             |
| `dropdownMode` (required) | `enum("scroll"\|"select")` |               |             |
| `locale`                  | `string`                   |               |             |
| `month` (required)        | `number`                   |               |             |
| `onChange` (required)     | `func`                     |               |             |
| `useShortMonthInDropdown` | `bool`                     |               |             |
