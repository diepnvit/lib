# `month_dropdown_options` (component)

| name                    | type                     | default value | description |
| ----------------------- | ------------------------ | ------------- | ----------- |
| `month` (required)      | `number`                 |               |             |
| `monthNames` (required) | `arrayOf[object Object]` |               |             |
| `onCancel` (required)   | `func`                   |               |             |
| `onChange` (required)   | `func`                   |               |             |
