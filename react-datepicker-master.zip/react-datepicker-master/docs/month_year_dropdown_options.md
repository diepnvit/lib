# `month_year_dropdown_options` (component)

| name                          | type     | default value | description |
| ----------------------------- | -------- | ------------- | ----------- |
| `date` (required)             | `object` |               |             |
| `dateFormat` (required)       | `string` |               |             |
| `maxDate` (required)          | `object` |               |             |
| `minDate` (required)          | `object` |               |             |
| `onCancel` (required)         | `func`   |               |             |
| `onChange` (required)         | `func`   |               |             |
| `scrollableMonthYearDropdown` | `bool`   |               |             |
