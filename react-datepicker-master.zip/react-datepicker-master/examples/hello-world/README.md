# React Datepicker Component Example

This is a very simple — yet runnable app — showing how to use React Datepicker component.

## Running Example

**In the project directory, run:**

```
$ npm install
$ npm start
```

Or if you're using Yarn:

```
yarn
yarn start
```

**Open [http://localhost:3000](http://localhost:3000) to view it in the browser.**

[User Guide](http://localhost:3000)
